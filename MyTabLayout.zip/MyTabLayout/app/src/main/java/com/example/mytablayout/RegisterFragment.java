// FragmentRegister.java
package com.example.mytablayout;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class RegisterFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        Button button_register = view.findViewById(R.id.button_register);
        button_register.setOnClickListener(v -> {
            // Berpindah ke FragmentLogin
            fragment_login fragmentLogin = new fragment_login();
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.viewPager, fragmentLogin) // Ganti dengan ID viewPager
                    .addToBackStack(null) // Tambahkan ke back stack agar bisa kembali
                    .commit();
        });

        return view;
    }
}
